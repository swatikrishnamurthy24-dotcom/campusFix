// mockNotifications.js — seed data for the Student Portal notifications
// screen (Phase 4). See src/services/issueService.js for the read/write
// abstraction.

const DEMO_STUDENT_ID = "u-student-01"

export const initialMockNotifications = [
  {
    id: "ntf-1",
    userId: DEMO_STUDENT_ID,
    type: "status",
    title: "Issue acknowledged",
    message: "Your issue \"Broken fan in Classroom 204\" has been acknowledged by Facilities.",
    issueId: "ISS-1001",
    read: false,
    createdAt: "2026-08-11T10:00:00.000Z",
  },
  {
    id: "ntf-2",
    userId: DEMO_STUDENT_ID,
    type: "status",
    title: "Issue in progress",
    message: "Your issue \"Broken fan in Classroom 204\" is now In Progress.",
    issueId: "ISS-1001",
    read: false,
    createdAt: "2026-08-14T11:00:00.000Z",
  },
  {
    id: "ntf-3",
    userId: DEMO_STUDENT_ID,
    type: "vote",
    title: "New upvote",
    message: "Your issue \"Projector not displaying in Lab 2\" received a new upvote.",
    issueId: "ISS-1003",
    read: false,
    createdAt: "2026-08-19T09:30:00.000Z",
  },
  {
    id: "ntf-4",
    userId: DEMO_STUDENT_ID,
    type: "comment",
    title: "Staff commented",
    message: "Facilities Team commented on \"Broken fan in Classroom 204\".",
    issueId: "ISS-1001",
    read: true,
    createdAt: "2026-08-14T11:05:00.000Z",
  },
  {
    id: "ntf-5",
    userId: DEMO_STUDENT_ID,
    type: "status",
    title: "Issue rejected",
    message: "Your issue \"Broken desk in Classroom 108\" was reviewed and marked Rejected. See details for the reason.",
    issueId: "ISS-1005",
    read: true,
    createdAt: "2026-07-30T09:10:00.000Z",
  },
]
