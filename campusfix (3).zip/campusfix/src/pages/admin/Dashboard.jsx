import { Badge } from "@/components/ui/badge"

/**
 * Placeholder Admin Dashboard.
 * Full version (system-wide stats, department breakdown, issue trends)
 * is built in a later step — see Phase 2 spec A2.
 */
export default function AdminDashboard() {
  return (
    <div className="space-y-4">
      <div className="rounded-lg border border-border bg-surface p-6">
        <div className="mb-2 flex items-center gap-2">
          <h2 className="text-lg font-semibold">Admin Dashboard</h2>
          <Badge variant="muted">Placeholder</Badge>
        </div>
        <p className="text-sm text-muted-foreground">
          This is a placeholder page confirming the Admin portal layout,
          sidebar, and routing work. System-wide stats, charts, and the
          "Needs Attention" table will be built in the next step.
        </p>
      </div>
    </div>
  )
}
