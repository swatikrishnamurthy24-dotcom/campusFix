import { Badge } from "@/components/ui/badge"

/**
 * Placeholder Staff Dashboard.
 * Full version (assigned/pending/in-progress counts, priority issues,
 * recent assignments) is built in a later step — see Phase 2 spec T2.
 */
export default function StaffDashboard() {
  return (
    <div className="space-y-4">
      <div className="rounded-lg border border-border bg-surface p-6">
        <div className="mb-2 flex items-center gap-2">
          <h2 className="text-lg font-semibold">Staff Dashboard</h2>
          <Badge variant="muted">Placeholder</Badge>
        </div>
        <p className="text-sm text-muted-foreground">
          This is a placeholder page confirming the Staff portal layout,
          sidebar, and routing work. Workload stats and assigned-issue
          widgets will be built in the next step.
        </p>
      </div>
    </div>
  )
}
