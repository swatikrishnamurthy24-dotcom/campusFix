// issueService.js
//
// Mock issue-reporting service for the Student Portal (Phase 4). Every
// function here returns a Promise and is shaped the way a real API client
// would be, so swapping this module for real `fetch` calls later shouldn't
// require touching any component — only this file.
//
// STATE NOTE: issues/notifications/votes live in a module-level array for
// the lifetime of the tab (mock "database"). This intentionally resets on a
// full page reload — there is no real backend yet, so nothing should be
// treated as durable. Only auth (src/context/AuthContext.jsx) persists to
// localStorage, and even that stores a session, not application data.

import { initialMockIssues } from "@/data/mockIssues"
import { initialMockNotifications } from "@/data/mockNotifications"

const MOCK_DELAY_MS = 350

function delay(ms = MOCK_DELAY_MS) {
  return new Promise((resolve) => setTimeout(resolve, ms))
}

function generateIssueId(issues) {
  const nextNum = issues.length + 1001
  return `ISS-${nextNum}`
}

// In-memory mock "tables" — module-scoped so every caller shares the same
// data for the lifetime of the tab.
let issues = [...initialMockIssues]
let notifications = [...initialMockNotifications]
// Tracks one vote per (userId, issueId) so a student can't vote twice.
// Map<string "userId::issueId", "up" | "down">
const voteRecords = new Map()

/** All issues (used where the portal design calls for campus-wide visibility). */
export async function getIssues() {
  await delay()
  return [...issues]
}

export async function getIssueById(issueId) {
  await delay()
  const issue = issues.find((i) => i.id === issueId)
  if (!issue) {
    throw new Error(`Issue ${issueId} was not found.`)
  }
  return { ...issue }
}

/** Issues reported by a specific student (used by "My Issues"). */
export async function getStudentIssues(userId) {
  await delay()
  return issues.filter((i) => i.reportedBy === userId).map((i) => ({ ...i }))
}

/**
 * Creates a new issue. `reportedBy`/`reportedByName` must come from the
 * authenticated user — callers should never let this be hand-entered.
 */
export async function createIssue({ reportedBy, reportedByName, ...fields }) {
  await delay(500)

  if (!reportedBy) {
    throw new Error("createIssue requires an authenticated reporter.")
  }

  const now = new Date().toISOString()
  const newIssue = {
    id: generateIssueId(issues),
    title: fields.title,
    description: fields.description,
    category: fields.category,
    location: fields.location,
    building: fields.building || "",
    floor: fields.floor || "",
    room: fields.room || "",
    priority: fields.priority,
    status: "Pending",
    reportedBy,
    reportedByName,
    createdAt: now,
    updatedAt: now,
    upvotes: 0,
    downvotes: 0,
    image: fields.image || null, // object URL only — see ReportIssue.jsx
    comments: [],
  }

  issues = [newIssue, ...issues]
  return { ...newIssue }
}

export async function updateIssue(issueId, patch) {
  await delay()
  let updated = null
  issues = issues.map((issue) => {
    if (issue.id !== issueId) return issue
    updated = { ...issue, ...patch, updatedAt: new Date().toISOString() }
    return updated
  })
  if (!updated) throw new Error(`Issue ${issueId} was not found.`)
  return { ...updated }
}

/**
 * Casts (or changes/removes) a vote on an issue for a given user.
 * voteType: "up" | "down".
 * - Voting the same direction again removes the vote (toggle off).
 * - Voting the other direction switches it.
 * A user can never hold more than one active vote on the same issue.
 */
export async function voteIssue(issueId, userId, voteType) {
  await delay(150)

  if (!userId) throw new Error("voteIssue requires an authenticated user.")
  if (!["up", "down"].includes(voteType)) throw new Error("voteType must be 'up' or 'down'.")

  const recordKey = `${userId}::${issueId}`
  const previousVote = voteRecords.get(recordKey)

  let updated = null
  issues = issues.map((issue) => {
    if (issue.id !== issueId) return issue

    let { upvotes, downvotes } = issue

    if (previousVote === voteType) {
      // Toggling the same vote off.
      if (voteType === "up") upvotes -= 1
      else downvotes -= 1
      voteRecords.delete(recordKey)
    } else {
      // New vote, or switching from the opposite direction.
      if (previousVote === "up") upvotes -= 1
      if (previousVote === "down") downvotes -= 1
      if (voteType === "up") upvotes += 1
      else downvotes += 1
      voteRecords.set(recordKey, voteType)
    }

    updated = { ...issue, upvotes, downvotes }
    return updated
  })

  if (!updated) throw new Error(`Issue ${issueId} was not found.`)
  return { issue: { ...updated }, userVote: voteRecords.get(recordKey) ?? null }
}

/** Returns the current user's vote on an issue, if any: "up" | "down" | null. */
export function getUserVote(issueId, userId) {
  return voteRecords.get(`${userId}::${issueId}`) ?? null
}

// ---- Notifications -------------------------------------------------------

export async function getNotifications(userId) {
  await delay()
  return notifications
    .filter((n) => n.userId === userId)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .map((n) => ({ ...n }))
}

export async function markNotificationRead(notificationId) {
  await delay(120)
  notifications = notifications.map((n) => (n.id === notificationId ? { ...n, read: true } : n))
}

export async function markAllNotificationsRead(userId) {
  await delay(120)
  notifications = notifications.map((n) => (n.userId === userId ? { ...n, read: true } : n))
}
