import { createBrowserRouter, RouterProvider, Navigate } from "react-router-dom"

import ProtectedRoute from "@/routes/ProtectedRoute"
import { roleMeta } from "@/routes/navConfig"
import { useAuth } from "@/hooks/useAuth"
import FullScreenLoader from "@/components/common/FullScreenLoader"

import Login from "@/pages/auth/Login"
import StudentLayout from "@/layouts/StudentLayout"
import StaffLayout from "@/layouts/StaffLayout"
import AdminLayout from "@/layouts/AdminLayout"

import StudentDashboard from "@/pages/student/Dashboard"
import StaffDashboard from "@/pages/staff/Dashboard"
import AdminDashboard from "@/pages/admin/Dashboard"

/**
 * RootRedirect — handles "/". Sends an authenticated visitor straight to
 * their own dashboard, and an unauthenticated one to /login, instead of
 * rendering any UI of its own.
 */
function RootRedirect() {
  const { isAuthenticated, isLoading, user } = useAuth()
  if (isLoading) return <FullScreenLoader />
  if (isAuthenticated) {
    return <Navigate to={roleMeta[user.role]?.dashboardPath ?? "/login"} replace />
  }
  return <Navigate to="/login" replace />
}

/**
 * Central route tree.
 *
 * Each role has its own layout route (StudentLayout/StaffLayout/AdminLayout)
 * so the sidebar + header are never re-rendered from scratch between pages
 * of the same portal. `handle.title` on each child route feeds AppLayout's
 * page title in the header — see components/layout/AppLayout.jsx.
 *
 * ProtectedRoute wraps each role's branch and checks auth + role before
 * rendering the layout underneath (see routes/ProtectedRoute.jsx).
 *
 * NOTE: this route tree is NOT the security boundary. It only controls what
 * the UI shows/hides — someone can still hit an API directly. Real
 * authorization must be enforced by the backend once one exists (Phase 1
 * §22-23); ProtectedRoute here is a UX convenience only.
 *
 * Only Dashboard is wired up per role so far — the rest of the nav items
 * (Report Issue, My Issues, etc.) are built in upcoming steps and will be
 * added here one page at a time.
 */
const router = createBrowserRouter([
  { path: "/", element: <RootRedirect /> },
  { path: "/login", element: <Login /> },

  {
    path: "/student",
    element: <ProtectedRoute allowedRoles={["student"]} />,
    children: [
      {
        element: <StudentLayout />,
        children: [
          { index: true, element: <StudentDashboard />, handle: { title: "Dashboard" } },
        ],
      },
    ],
  },

  {
    path: "/staff",
    element: <ProtectedRoute allowedRoles={["staff"]} />,
    children: [
      {
        element: <StaffLayout />,
        children: [
          { index: true, element: <StaffDashboard />, handle: { title: "Dashboard" } },
        ],
      },
    ],
  },

  {
    path: "/admin",
    element: <ProtectedRoute allowedRoles={["admin"]} />,
    children: [
      {
        element: <AdminLayout />,
        children: [
          { index: true, element: <AdminDashboard />, handle: { title: "Dashboard" } },
        ],
      },
    ],
  },

  // Fallback: unknown paths resolve the same way "/" does.
  { path: "*", element: <RootRedirect /> },
])

export default function AppRoutes() {
  return <RouterProvider router={router} />
}
