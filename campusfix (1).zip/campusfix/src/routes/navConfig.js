// Sidebar navigation config per role, sourced directly from the
// Phase 1 Blueprint (Sections 8-10) and Phase 2 UI/UX Spec (Sections 4-6).
// Kept as data (not JSX) so Sidebar.jsx stays a single reusable component
// across all three portals.

import {
  LayoutDashboard,
  PlusCircle,
  ListChecks,
  MapPin,
  Bell,
  History,
  Star,
  UserCircle,
  Settings,
  LogOut,
  AlertTriangle,
  ClipboardList,
  Paperclip,
  MessageSquare,
  BarChart3,
  Users,
  Building2,
  Wifi,
  FileBarChart,
  SlidersHorizontal,
  Inbox,
  Hourglass,
  Loader,
} from "lucide-react"

export const studentNav = [
  { label: "Dashboard", to: "/student", icon: LayoutDashboard, end: true },
  { label: "Report Issue", to: "/student/report-issue", icon: PlusCircle },
  { label: "My Issues", to: "/student/my-issues", icon: ListChecks },
  { label: "Campus Map", to: "/student/campus-map", icon: MapPin },
  { label: "Notifications", to: "/student/notifications", icon: Bell },
  { label: "Issue History", to: "/student/issue-history", icon: History },
  { label: "Feedback", to: "/student/feedback", icon: Star },
  { label: "My Profile", to: "/student/profile", icon: UserCircle },
  { label: "Settings", to: "/student/settings", icon: Settings },
]

export const staffNav = [
  { label: "Dashboard", to: "/staff", icon: LayoutDashboard, end: true },
  { label: "Assigned Issues", to: "/staff/assigned-issues", icon: ClipboardList },
  { label: "Priority Issues", to: "/staff/priority-issues", icon: AlertTriangle },
  { label: "Campus Map", to: "/staff/campus-map", icon: MapPin },
  { label: "Work Management", to: "/staff/work-management", icon: ListChecks },
  { label: "Attachments", to: "/staff/attachments", icon: Paperclip },
  { label: "Comments", to: "/staff/comments", icon: MessageSquare },
  { label: "Performance", to: "/staff/performance", icon: BarChart3 },
  { label: "Notifications", to: "/staff/notifications", icon: Bell },
  { label: "Profile", to: "/staff/profile", icon: UserCircle },
  { label: "Settings", to: "/staff/settings", icon: Settings },
]

export const adminNav = [
  { label: "Dashboard", to: "/admin", icon: LayoutDashboard, end: true },
  { label: "Students", to: "/admin/students", icon: Users },
  { label: "Staff & Teachers", to: "/admin/staff", icon: Users },
  { label: "Departments", to: "/admin/departments", icon: Building2 },
  { label: "All Issues", to: "/admin/all-issues", icon: Inbox },
  { label: "Pending Issues", to: "/admin/pending-issues", icon: Hourglass },
  { label: "In Progress", to: "/admin/in-progress", icon: Loader },
  { label: "Emergency Issues", to: "/admin/emergency-issues", icon: AlertTriangle },
  { label: "Campus Map", to: "/admin/campus-map", icon: MapPin },
  { label: "Network Monitoring", to: "/admin/network-monitoring", icon: Wifi },
  { label: "Analytics", to: "/admin/analytics", icon: BarChart3 },
  { label: "Reports", to: "/admin/reports", icon: FileBarChart },
  { label: "Notifications", to: "/admin/notifications", icon: Bell },
  { label: "System Settings", to: "/admin/system-settings", icon: SlidersHorizontal },
]

export const roleMeta = {
  student: { label: "Student Portal", nav: studentNav },
  staff: { label: "Staff Portal", nav: staffNav },
  admin: { label: "Admin Portal", nav: adminNav },
}

export { LogOut }
