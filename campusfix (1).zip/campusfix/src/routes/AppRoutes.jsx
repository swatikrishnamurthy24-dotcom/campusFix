import { createBrowserRouter, RouterProvider } from "react-router-dom"

import DevHome from "@/pages/DevHome"
import StudentLayout from "@/layouts/StudentLayout"
import StaffLayout from "@/layouts/StaffLayout"
import AdminLayout from "@/layouts/AdminLayout"

import StudentDashboard from "@/pages/student/Dashboard"
import StaffDashboard from "@/pages/staff/Dashboard"
import AdminDashboard from "@/pages/admin/Dashboard"

/**
 * Central route tree.
 *
 * Each role has its own layout route (StudentLayout/StaffLayout/AdminLayout)
 * so the sidebar + header are never re-rendered from scratch between pages
 * of the same portal. `handle.title` on each child route feeds AppLayout's
 * page title in the header — see components/layout/AppLayout.jsx.
 *
 * NOTE: this route tree is NOT the security boundary. Anyone can currently
 * type /admin into the address bar — real role enforcement happens on the
 * backend once auth exists (Phase 1 §23). A route guard will be added here
 * later, but it will only ever be a UX convenience, not real protection.
 *
 * Only Dashboard is wired up per role so far — the rest of the nav items
 * (Report Issue, My Issues, etc.) are built in upcoming steps and will be
 * added here one page at a time.
 */
const router = createBrowserRouter([
  { path: "/", element: <DevHome /> },

  {
    path: "/student",
    element: <StudentLayout />,
    children: [
      { index: true, element: <StudentDashboard />, handle: { title: "Dashboard" } },
    ],
  },

  {
    path: "/staff",
    element: <StaffLayout />,
    children: [
      { index: true, element: <StaffDashboard />, handle: { title: "Dashboard" } },
    ],
  },

  {
    path: "/admin",
    element: <AdminLayout />,
    children: [
      { index: true, element: <AdminDashboard />, handle: { title: "Dashboard" } },
    ],
  },
])

export default function AppRoutes() {
  return <RouterProvider router={router} />
}
