import { Outlet, useMatches } from "react-router-dom"
import Sidebar from "@/components/layout/Sidebar"
import TopHeader from "@/components/layout/TopHeader"

/**
 * AppLayout — the shared shell (sidebar + header + content area) used by
 * every role-based layout. Role-specific pieces (nav items, role label,
 * mock user) are passed in as props by StudentLayout/StaffLayout/AdminLayout,
 * so this component itself has no idea which portal it's rendering.
 *
 * pageTitle is resolved from the active route's `handle.title` (set per
 * route in AppRoutes.jsx) so each page doesn't need to manage the header.
 */
export default function AppLayout({ navItems, roleLabel, userName, userInitials }) {
  const matches = useMatches()
  const current = [...matches].reverse().find((m) => m.handle?.title)
  const pageTitle = current?.handle?.title ?? roleLabel

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar navItems={navItems} roleLabel={roleLabel} />

      <div className="flex min-w-0 flex-1 flex-col lg:pl-60">
        <TopHeader
          pageTitle={pageTitle}
          navItems={navItems}
          roleLabel={roleLabel}
          userName={userName}
          userInitials={userInitials}
        />
        <main className="flex-1 p-4 sm:p-6">
          <Outlet />
        </main>
      </div>
    </div>
  )
}
