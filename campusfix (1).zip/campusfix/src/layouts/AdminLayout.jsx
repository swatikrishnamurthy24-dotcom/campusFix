import AppLayout from "@/components/layout/AppLayout"
import { adminNav, roleMeta } from "@/routes/navConfig"

// Mock signed-in user for now — real identity comes from the backend later.
const MOCK_ADMIN = { name: "Priya M.", initials: "PM" }

export default function AdminLayout() {
  return (
    <AppLayout
      navItems={adminNav}
      roleLabel={roleMeta.admin.label}
      userName={MOCK_ADMIN.name}
      userInitials={MOCK_ADMIN.initials}
    />
  )
}
