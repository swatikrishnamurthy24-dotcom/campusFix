import AppLayout from "@/components/layout/AppLayout"
import { staffNav, roleMeta } from "@/routes/navConfig"

// Mock signed-in user for now — real identity comes from the backend later.
const MOCK_STAFF = { name: "Arjun K.", initials: "AK" }

export default function StaffLayout() {
  return (
    <AppLayout
      navItems={staffNav}
      roleLabel={roleMeta.staff.label}
      userName={MOCK_STAFF.name}
      userInitials={MOCK_STAFF.initials}
    />
  )
}
