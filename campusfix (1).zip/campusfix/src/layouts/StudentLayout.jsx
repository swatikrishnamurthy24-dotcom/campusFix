import AppLayout from "@/components/layout/AppLayout"
import { studentNav, roleMeta } from "@/routes/navConfig"

// Mock signed-in user for now — real identity comes from the backend later
// (see Phase 1 §23 Authentication and Authorization Concept).
const MOCK_STUDENT = { name: "Swati R.", initials: "SR" }

export default function StudentLayout() {
  return (
    <AppLayout
      navItems={studentNav}
      roleLabel={roleMeta.student.label}
      userName={MOCK_STUDENT.name}
      userInitials={MOCK_STUDENT.initials}
    />
  )
}
