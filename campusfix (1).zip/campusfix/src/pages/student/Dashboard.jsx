import { Badge } from "@/components/ui/badge"

/**
 * Placeholder Student Dashboard.
 * Full version (stat cards, recent issues, quick-report CTA) is built in
 * a later step once we have mock issue data — see Phase 2 spec S3.
 */
export default function StudentDashboard() {
  return (
    <div className="space-y-4">
      <div className="rounded-lg border border-border bg-surface p-6">
        <div className="mb-2 flex items-center gap-2">
          <h2 className="text-lg font-semibold">Student Dashboard</h2>
          <Badge variant="muted">Placeholder</Badge>
        </div>
        <p className="text-sm text-muted-foreground">
          This is a placeholder page confirming the Student portal layout,
          sidebar, and routing work. Stat cards, recent issues, and the
          quick "Report Issue" shortcut will be built in the next step.
        </p>
      </div>
    </div>
  )
}
