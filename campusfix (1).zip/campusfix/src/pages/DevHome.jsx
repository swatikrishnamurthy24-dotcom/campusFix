import { Link } from "react-router-dom"
import { GraduationCap, Wrench, ShieldCheck } from "lucide-react"

/**
 * TEMPORARY / MOCK — this page is a dev-only stand-in for the login screen.
 * Real authentication (Phase 1 §23) and the actual Login UI (Phase 2 §4.2 S1)
 * are not built yet. Once auth exists, this page is deleted and "/" will
 * redirect to the login screen instead.
 *
 * It exists only so we can verify all three role-based layouts and their
 * routing without building auth first, per the current development step.
 */
export default function DevHome() {
  const portals = [
    { role: "Student", to: "/student", icon: GraduationCap, desc: "Report and track campus issues" },
    { role: "Staff / Teacher", to: "/staff", icon: Wrench, desc: "Resolve assigned issues" },
    { role: "Admin", to: "/admin", icon: ShieldCheck, desc: "Manage the whole system" },
  ]

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="w-full max-w-md rounded-lg border border-border bg-surface p-8 shadow-sm">
        <div className="mb-1 flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-md bg-primary text-sm font-bold text-primary-foreground">
            CF
          </div>
          <h1 className="text-lg font-semibold">CampusFix</h1>
        </div>
        <p className="mb-6 text-sm text-muted-foreground">
          Report. Track. Resolve. Improve. — Saptagiri NPS University
        </p>

        <p className="mb-3 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
          Dev preview &mdash; choose a portal (mock, no login yet)
        </p>

        <div className="flex flex-col gap-2">
          {portals.map(({ role, to, icon: Icon, desc }) => (
            <Link
              key={to}
              to={to}
              className="flex items-center gap-3 rounded-md border border-border p-3 transition-colors hover:border-primary hover:bg-muted"
            >
              <Icon className="h-5 w-5 shrink-0 text-primary" />
              <span>
                <span className="block text-sm font-medium">{role}</span>
                <span className="block text-xs text-muted-foreground">{desc}</span>
              </span>
            </Link>
          ))}
        </div>
      </div>
    </div>
  )
}
